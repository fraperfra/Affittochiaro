"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// lambdas/api/payments/createPortal.ts
var createPortal_exports = {};
__export(createPortal_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(createPortal_exports);

// lambdas/shared/utils/response.ts
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token",
  "Access-Control-Allow-Methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS",
  "Content-Type": "application/json"
};
function apiResponse(statusCode, body, headers) {
  return {
    statusCode,
    headers: { ...CORS_HEADERS, ...headers },
    body: JSON.stringify(body)
  };
}
function success(data, pagination) {
  const response = {
    success: true,
    data,
    pagination
  };
  return apiResponse(200, response);
}
function internalError(message = "Internal server error") {
  return apiResponse(500, { success: false, error: message });
}

// lambdas/api/payments/createPortal.ts
var handler = async (event) => {
  try {
    return success({ message: "Not implemented yet" });
  } catch (error) {
    console.error("Error:", error);
    return internalError("Internal server error");
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
//# sourceMappingURL=createPortal.js.map
